import os

BOT_TOKEN = os.getenv("BOT_TOKEN")